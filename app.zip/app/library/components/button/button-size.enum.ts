export enum ButtonSize {
    SMALL = 'button-size-small',
    MEDIUM = 'button-size-medium',
    LARGE = 'button-size-large'
  }