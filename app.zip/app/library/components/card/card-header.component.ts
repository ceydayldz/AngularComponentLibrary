import { Component } from '@angular/core';

@Component({
  selector: 'foo-card-header',
  template: `<ng-content></ng-content>`
})
export class CardHeaderComponent {}