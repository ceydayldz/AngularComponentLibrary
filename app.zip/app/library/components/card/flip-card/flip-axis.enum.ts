export enum FlipAxis {
    X = 'flip-axis-x',
    Y = 'flip-axis-y'
  }