import { Component } from '@angular/core';

@Component({
  selector: 'foo-front-card',
  template: `<ng-content></ng-content>`
})
export class FrontCardComponent {}