import { Component } from '@angular/core';

@Component({
  selector: 'foo-back-card',
  template: `<ng-content></ng-content>`
})
export class BackCardComponent {}