export enum ToastType {
    PRIMARY = 'toast-primary',
    SECONDARY = 'toast-secondary',
    SUCCESS = 'toast-success',
    INFO = 'toast-info',
    WARNING = 'toast-warning',
    DANGER = 'toast-danger'
  }