export enum SpinnerSize {
    SMALL = 'spinner-size-sm',
    MEDIUM = 'spinner-size-md',
    LARGE = 'spinner-size-lg'
  }