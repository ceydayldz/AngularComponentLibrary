export enum AlertType {
    PRIMARY = "alert-primary",
    SECONDARY = "alert-secondary",
    SUCCESS = "alert-success",
    INFO = "alert-info",
    WARNING = "alert-warning",
    DANGER = "alert-danger"
  }