export enum ProgressBarFill {
    PRIMARY = 'progress-bar-fill-primary',
    SECONDARY = 'progress-bar-fill-secondary',
    SUCCESS = 'progress-bar-fill-success',
    INFO = 'progress-bar-fill-info',
    WARNING = 'progress-bar-fill-warning',
    DANGER = 'progress-bar-fill-danger'
  }