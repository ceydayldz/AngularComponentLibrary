import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-side-panel',
  templateUrl: './home-side-panel.component.html',
  styleUrls: ['./home-side-panel.component.scss']
})
export class HomeSidePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}