import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CardModule, OverlaySidePanelModule, ButtonModule } from '../../library/components';
import { SharedModule } from '../../shared/shared.module';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { DashboardSidePanelMoreComponent } from './dashboard-side-panel-more/dashboard-side-panel-more.component'
import { DashboardSidePanelComponent } from './dashboard-side-panel/dashboard-side-panel.component';
import { GridContainerComponent } from 'src/app/shared/components/grid/grid-container/grid-container.component';


@NgModule({
  imports: [
    CommonModule,
    CardModule,
    DashboardRoutingModule,
    OverlaySidePanelModule,
    
    ButtonModule
  ],
  declarations: [
    DashboardComponent,
    DashboardSidePanelMoreComponent,
    DashboardSidePanelComponent,
    GridContainerComponent
  ],

})
export class DashboardModule { }