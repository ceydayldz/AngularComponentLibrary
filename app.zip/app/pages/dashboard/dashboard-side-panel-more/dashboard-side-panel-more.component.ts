import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-side-panel-more',
  templateUrl: './dashboard-side-panel-more.component.html',
  styleUrls: ['./dashboard-side-panel-more.component.scss']
})
export class DashboardSidePanelMoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}