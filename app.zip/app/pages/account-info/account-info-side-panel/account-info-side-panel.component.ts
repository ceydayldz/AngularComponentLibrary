import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-info-side-panel',
  templateUrl: './account-info-side-panel.component.html',
  styleUrls: ['./account-info-side-panel.component.scss']
})
export class AccountInfoSidePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}