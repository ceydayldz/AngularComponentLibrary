
export enum SidePanelState {
    OPEN = "open",
    CLOSE = "close",
    COLLAPSE = "collapse"
  }