import { Directive, HostListener, Output, EventEmitter } from '@angular/core';

@Directive({
  selector: '[singleDoubleClick]'
})
export class SingleDoubleClickDirective {

  @Output()
  public onSingleClick: EventEmitter<void>;

  @Output()
  public onDoubleClick: EventEmitter<void>;

  private _singleClickTimeout:number=0;
  private _isDoubleClick: boolean;

  constructor() {
    this._isDoubleClick = false;
    this.onSingleClick = new EventEmitter<void>();
    this.onDoubleClick = new EventEmitter<void>();
  }

  // @HostListener('click', ['$event'])
  // private onClick(event: MouseEvent) {
  //   event.stopPropagation();
  //   if (this._isDoubleClick === true) {
      
  //     clearTimeout(this._singleClickTimeout);
  //     this._isDoubleClick = false;
  //     this.onDoubleClick.next()
  //   } else {
  //     this._isDoubleClick = true;
  //     this._singleClickTimeout = setTimeout(() => {
  //       this.onSingleClick.next();
  //       this._isDoubleClick = false;
  //     }, 250);
  //   }
  // }
  @HostListener('click', ['$event'])
  private onClick(event: MouseEvent) {
    event.stopPropagation();
    if (this._isDoubleClick === true) {
      clearTimeout(this._singleClickTimeout);
      this._isDoubleClick = false;
      this.onDoubleClick.next()
    } else {
      this._isDoubleClick = true;
      this._singleClickTimeout = window.setTimeout(() => {
        this.onSingleClick.next();
        this._isDoubleClick = false;
      }, 250);
    }
  }
}